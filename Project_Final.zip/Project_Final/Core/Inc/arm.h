#include "main.h"

void SetServoPosition(TIM_HandleTypeDef *htim, uint32_t channel, uint32_t position, uint32_t delayMs);

void OpenClaw(void);

void CloseClaw(void);

void MoveArmForward(uint32_t position);

void RotateArm(uint32_t position);

void LiftArm(uint32_t position);

void OperateArm(void);
