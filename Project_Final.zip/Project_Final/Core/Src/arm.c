#include "arm.h"

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;


void SetServoPosition(TIM_HandleTypeDef *htim, uint32_t channel, uint32_t position, uint32_t delayMs)
{
   __HAL_TIM_SET_COMPARE(htim, channel, position);
    HAL_Delay(delayMs);
}

void OpenClaw(void)
{
    SetServoPosition(&htim2, TIM_CHANNEL_2, 500, 500);
}

void CloseClaw(void)
{
    SetServoPosition(&htim2, TIM_CHANNEL_2, 1000, 1000);
}

void MoveArmForward(uint32_t position)
{
    SetServoPosition(&htim2, TIM_CHANNEL_1, position, 500);
}

void RotateArm(uint32_t position)
{
    SetServoPosition(&htim3, TIM_CHANNEL_1, position, 500);
}

void LiftArm(uint32_t position)
{
    SetServoPosition(&htim3, TIM_CHANNEL_2, position, 500);
}



void OperateArm(void)
{
    // Abrir garra
    OpenClaw();

    // Avança para pegar o objeto
    MoveArmForward(800);

    // Fechar a garra
    CloseClaw();

    // Retorna o braço (desfaz o avanço)
    MoveArmForward(500);

    // Rotaciona para depositar o objeto
    RotateArm(1000);

    // Abrir a garra para liberar o objeto
    OpenClaw();

    // Levanta o braço para evitar colisões
    LiftArm(1000);

    // Rotaciona o braço para posição inicial
    RotateArm(500);

    // Abaixa o braço para a posição inicial
    LiftArm(900);

    // Garantir que o braço e a garra estão na posição inicial
    MoveArmForward(500);
}
